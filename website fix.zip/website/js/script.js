document.getElementById("action").onclick = function () {
    location.href = "contactus.html";
};

function required() {
    var name = document.getElementById("name").value;
    var email = document.getElementById("email").value;
    if (name != "" &&  email != "" ) {
    return true;
    }
    else 
    {
    alert('Please fill the form completely');
    }
}

function validateEmail()
{
var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
var email = document.getElementById("email");
if(email.value.match(mailformat))
{
email.focus();
return true;
}
else
{
alert("You have entered an invalid email address!");
email.focus();
return false;
}
}

function allLetter() {
    var textValidation = /^[a-zA-Z ]+$/;
    var name = document.getElementById("name");
    if (name.value.match(textValidation)) {
       return true
    } else {
       alert("Child and guardian name containing alphabet only!");
       name.value="";
       name.focus();
       return false;
    }
  }
